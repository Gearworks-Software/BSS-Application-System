const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const port = 3000;

// Middleware to parse form data
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static files from the 'public' folder (CSS, images, etc.)
app.use(express.static(path.join(__dirname, 'public')));

// Serve the login page (index.html)
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Handle login POST request
app.post('/dashboard', (req, res) => {
  const email = req.body.email;
  const password = req.body.password;

  // Placeholder logic for checking login credentials
  if (email === "user@example.com" && password === "password123") {
    // Redirect to the status page after successful login
    res.redirect('/status');
  } else {
    res.send('<h1>Login failed</h1><p>Invalid Email or Password. <a href="/">Try again</a></p>');
  }
});

// Serve the status page (status.html)
app.get('/status', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'status.html'));
});

// Start the server
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
